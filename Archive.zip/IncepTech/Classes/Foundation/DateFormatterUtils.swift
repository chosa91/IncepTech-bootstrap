import Foundation

class DateFormatterUtils
{
    static let singleton = DateFormatter()
}
